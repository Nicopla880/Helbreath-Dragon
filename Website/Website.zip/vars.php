<?php
 $mysql_ip =	"HBInternational.ddns.net";
 $mysql_user =	"helbreath";
 $mysql_pw =	"helbreath";
 $mysql_db =	"international";
?>